<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<style scoped>
  @import './address_base.css';
  @import './address.css';
</style>




